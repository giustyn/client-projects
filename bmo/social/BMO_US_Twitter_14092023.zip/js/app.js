(function () {
  const BMO = { Name: "BMO", Logo: "./img/bmo-logo.svg" };
  const socialProvider = [
    {
      Id: 24,
      Name: "X (Twitter)",
      Logo: "./img/logo_x_white-round.svg",
    },
    {
      Id: 25,
      Name: "Instagram",
      Logo: "./img/logo_instagram.svg",
    },
    {
      Id: 26,
      Name: "Facebook",
      Logo: "./img/logo_facebook.svg",
    },
  ][0];

  const dataURI = {
    bmo_US:
      "https://kitchen.screenfeed.com/social/data/6w24z789gena94j8yt3728zgzw.json",
    bmo_CA:
      "https://kitchen.screenfeed.com/social/data/4qsr8pzd9vpp64n6cx26kazya3.json",
  };

  let feeds = [],
    limit = 3,
    timerDuration = 10000;

  function setContent($template, data, index) {
    const $container = $("main");
    const $clone = $template.clone();
    $template.remove();

    $clone.attr({ id: data.ContentId }).css("z-index", feeds.length - index);
    $clone.find(".username").text(data.User.Name);
    $clone.find(".useraccount").text(data.User.Username);
    $clone.find(".usericon img").attr("src", BMO.Logo);
    $clone.find(".socialicon img").attr("src", socialProvider.Logo);
    $clone.find(".message").text(data.Content);
    $clone.find(".published").text(data.DisplayTime);
    $clone.find(".media video, .media img").attr("src", data.Images[0].Url);
    $container.append($clone);

    resizeText({ elements: $clone[0].querySelectorAll(".message") });
    isolateTag({ element: $clone[0].querySelectorAll(".message") });
  }

  function animateTemplate(data) {
    const articleId = document.getElementById(data.ContentId);
    articleId.classList.add("active");
    let sliderId = setTimeout(() => {
      articleId.classList.remove("active");
    }, timerDuration);
  }

  function iterateAnimations(num) {
    let index = 0;
    animateTemplate(feeds[index]);
    index = index + 1;
    let interval = setInterval(() => {
      if (index < num) {
        animateTemplate(feeds[index]);
        index = index + 1;
      } else {
        clearInterval(interval);
      }
    }, timerDuration);
  }

  function isOver30Days(obj) {
    const pastTime = new Date(obj);
    const now = new Date();
    const thirtyDaysInMs = 30 * 24 * 60 * 60 * 1000;
    const timeDiffInMs = now.getTime() - pastTime.getTime();
    if (timeDiffInMs >= thirtyDaysInMs) return true;
    return false;
  }

  function onTemplateError(result) {
    console.warn(result);
  }

  function onTemplateSuccess(result) {
    const results = result.Items;
    const $template = $("article");

    results.forEach((el) => {
      feeds.push(el);
    });
    feeds = feeds
      .filter((obj) => obj.Provider == socialProvider.Id)
      .filter((obj) => obj.Images.length != 0) // remove posts without images
      .filter((obj) => isOver30Days(obj.CreatedDate) != true) // remove posts older than 30 days
      .sort((a, b) => {
        if (a.CreatedDate > b.CreatedDate) return -1;
      })
      .splice(0, limit); // reduce number of posts to 3

    timerDuration = (limit * timerDuration) / feeds.length;
    // console.log(timerDuration, feeds.length);

    feeds.forEach((el, i) => {
      setContent($template, el, i);
    });

    iterateAnimations(feeds.length);
  }

  async function getLocalStorageData(onSuccess, onError, data) {
    let now = new Date().getTime();
    let exp = now + 1000 * 60 * 10; // 10 minutes
    //attempt to get data from localStorage
    if (localStorage.getItem(data)) {
      var expiry = JSON.parse(localStorage.getItem(data + "_expired"));
      if (now <= expiry) {
        var result = JSON.parse(localStorage.getItem(data));
        onSuccess(result);
        console.log("localStorage:", Object.keys(localStorage));
        return;
      }
    }
    try {
      const response = await fetch(data);
      if (!response.ok) {
        throw new Error("Network response was not OK");
      }
      const results = await response.json();
      localStorage.setItem(data, JSON.stringify(results));
      localStorage.setItem(data + "_expired", JSON.stringify(exp));
      console.log("saved to localStorage:", Object.keys(localStorage));
      onSuccess(results);
    } catch (error) {
      onError(error);
    }
  }

  async function getData(onSuccess, onError, data) {
    try {
      const response = await fetch(data);
      if (!response.ok) throw new Error("Network response was not OK");
      const results = await response.json();
      onSuccess(results);
    } catch (error) {
      onError(error);
    }
  }

  function init() {
    getData(onTemplateSuccess, onTemplateError, dataURI.bmo_US);
    // getData(onTemplateSuccess, onTemplateError, dataURI.bmo_CA);
  }

  init(diag(false));
})();
