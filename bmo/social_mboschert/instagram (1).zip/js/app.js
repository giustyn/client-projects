(function () {
  const userName = "BMO",
    userIcon = "./img/bmo-logo.svg",
    timerDuration = 10000,
    revealerSpeed = 1500;

  const dataURI = {
    local: "c:\\data\\social\\social.json",
    server:
      "http://kitchen.screenfeed.com/social/data/6w24z789gena94j8yt3728zgzw.json",
  };

  let feeds = [],
    current = 0;

  function animateTemplate(data, current) {
    const $template = document.getElementsByTagName("article")[0];
    const $container = document.getElementsByTagName("main")[0];
    const $clone = $template.cloneNode(true);
    $clone.classList.remove("main");

    let ProfileImageUrl = data.User.ProfileImageUrl,
      ProfileUserName = data.User.Name,
      MediaUrl = {};

    if (data.Images.length == 0) MediaUrl = userIcon;
    if (data.Images.length == 1) MediaUrl = data.Images[0].Url;
    $clone
      .querySelectorAll(".media video, .media img")
      .forEach((elem) => elem.setAttribute("src", MediaUrl));

    if (!data.User.ProfileImageUrl) {
      // use default instagram image & username
      ProfileImageUrl = userIcon;
      ProfileUserName = userName;
    }

    $clone.setAttribute("id", current);
    $clone.style.zIndex = current;
    $clone.classList.remove("hidden");
    $clone
      .querySelectorAll(".socialicon img")
      .forEach((icon) => icon.setAttribute("src", data.ProviderIcon));
    $clone
      .querySelectorAll(".username")
      .forEach((icon) => (icon.innerText = ProfileUserName));
    $clone
      .querySelectorAll(".useraccount")
      .forEach((icon) => (icon.innerText = data.User.Username));
    $clone
      .querySelectorAll(".usericon img")
      .forEach((icon) => icon.setAttribute("src", ProfileImageUrl));
    $clone
      .querySelectorAll(".message")
      .forEach((icon) => (icon.innerText = data.Content));
    $clone
      .querySelectorAll(".published")
      .forEach((icon) => (icon.innerText = data.DisplayTime));
    $container.append($clone);

    setTimeout(function () {
      $clone.remove();
    }, timerDuration + revealerSpeed * 2);
  }

  function iterateAnimations() {
    animateTemplate(feeds[current], current);
    current = (current + 1) % feeds.length;

    setTimeout(iterateAnimations, timerDuration);
  }

  function onTemplateError(result) {
    console.warn(result);
    console.warn("could not get data");
  }

  function onTemplateSuccess(result) {
    feeds = [
      ...new Map(result.Items.map((item) => [item.Content, item])).values(),
    ]
      .filter(
        (item) => item.Provider == 25 && item.Images.length == 1 && item.Content
      )
      .sort(
        (a, b) =>
          new Date(b.CreatedDate).getTime() - new Date(a.CreatedDate).getTime()
      );

    iterateAnimations();
  }

  async function getJsonData(onSuccess, onError, data) {
    try {
      const response = await fetch(data);
      if (!response.ok) {
        throw new Error("Network response was not OK");
      }
      const results = await response.json();
      onSuccess(results);
    } catch (error) {
      onError(error);
    }
  }

  function init() {
    // getJsonData(onTemplateSuccess, onTemplateError, dataURI.local); // get local data, located at c:\data
    getJsonData(onTemplateSuccess, onTemplateError, dataURI.server); // get server data, via screenfeed.com
  }

  init();
})();
